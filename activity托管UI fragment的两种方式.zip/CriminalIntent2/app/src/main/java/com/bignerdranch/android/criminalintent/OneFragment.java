package com.bignerdranch.android.criminalintent;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class OneFragment extends Fragment {

    private Crime mCrime;
    private static final String TAG = "MainActivity";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG,"onFragmentCreate(Bundle) called");
        mCrime = new Crime();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_one, container, false);

        return v;
    }
    @Override
    public void onStart() {
        super.onStart();
        Log.d(TAG,"onFragmentStart() called");
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d(TAG,"onFragmentResume() called");
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.d(TAG,"onFragmentPause() called");
    }

    @Override
    public void onStop() {
        super.onStop();
        Log.d(TAG,"onFragmentStop() called");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG,"onFragmentDestroy() called");
    }
}
